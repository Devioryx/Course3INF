import Text.Regex.TDFA ((=~)) 

main :: IO ()
main = do
    input <- readFile "input.txt" 
    let finds = input =~ "mul\\(\\d{1,3},\\d{1,3}\\)" :: [[String]]
    print finds